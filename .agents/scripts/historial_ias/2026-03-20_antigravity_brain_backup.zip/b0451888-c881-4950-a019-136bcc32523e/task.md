# Plan de Trabajo (1 Hora) — Sesión Gemini

**Objetivo:** Abordar la "Cuestión previa" definida por Claude y cerrar la "Fase 1" de los GAPs (decisiones macro y GAPs cortos), dejando el código de ejemplo (`.trz`) actualizado y documentado.

- [x] **1. Decisión Previa: Tipos de contexto en `system.trz` (15 min)**
    - [x] Analizar la propuesta de Claude: `contexts:`, `overlays:`, `concurrent:`.
    - [x] Validar la inferencia vs. declaración explícita (enfocado en la *Opacidad criptográfica*).
    - [x] Tomar la decisión, documentarla brevemente y actualizar `examples/cronometro-psp/helix/system.helix` (o `.trz`) al nuevo formato.
- [x] **2. GAP-8: Acciones "ignorar" (15 min)**
    - [x] Evaluar la propuesta: palabra reservada `ignorar` vs handler vacío.
    - [x] Confirmar `ignorar` como palabra clave reservada del lenguaje (intención explícita).
    - [x] Actualizar los archivos `.trz` del cronómetro que utilicen este concepto (ej. `ModoNormal.trz`, `EditandoTarea.trz`).
- [x] **3. GAP-6: Datos mutables vs Inmutables (15 min)**
    - [x] Evaluar propuesta: modificador explícito `mutable` (por defecto `readonly`).
    - [x] Modificar `examples/cronometro-psp/helix/data.helix` para aplicar el prefijo `mutable` donde corresponda.
- [x] **4. Cierre y Documentación (15 min)**
    - [x] Redactar memo corto o actualizar un documento de diseño con las tres reglas/decisiones establecidas.
    - [x] Dejar preparado el terreno para que la siguiente sesión aborde la Fase 2 (GAP-1 y GAP-2).
