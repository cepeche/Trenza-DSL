# Plan de Implementación: Reestructuración v0.0.1

**Objetivo**: Congelar la v0.0.0 (Especificación Inicial) y reestructurar todo el repositorio de Trenza DSL a la nueva arquitectura propuesta por Opus (`2026-03-20-05-propuesta-estructura-v001.md`) y refinada por Antigravity (`2026-03-20-07-memo-gemini-respuesta-v001.md`).

## ⚠️ User Review Required
Este plan moverá decenas de archivos usando `git mv` para preservar el historial y creará una nueva topología de carpetas. Necesito tu confirmación antes de iniciar este proceso destructivo/constructivo, ya que afectará enormemente a tu espacio de trabajo.

---

## Proposed Changes

### Fase 1: Sellado y Sanitización
Antes de mover carpetas, debemos asegurar que el código base está limpio y sellado bajo la etiqueta v0.0.0.

#### [Pasos de Terminal CLI]
1. Ejecutar `git add .` y `git commit -m "chore: consolidación final de documentos antes de v0.0.0"` (para asegurar que nuestros Demos de PI y Respuestas están guardados).
2. Ejecutar `git tag -a v0.0.0 -m "Primera especificación completa de Trenza (8/8 GAPs resueltos)"`.
3. Búsqueda y reemplazo global (`Find & Replace`): Cambiar la palabra `bloqueado` por `forbidden` en todos los archivos `.trz` del ejemplo `cronometro-psp`, y verificar si hay referencias en `parser.py` o `ast.py`. *(Esto cubre nuestra corrección del GAP).*

### Fase 2: El Gran Refactor (Git MV)
Usaremos un pequeño script de Python o comandos directos para crear las nuevas carpetas y mover los archivos manteniendo la historia de Git.

#### [Operaciones de Carpeta]
Crearemos la siguiente estructura base:
- `spec/language/`
- `spec/reference/`
- `docs/design/`
- `docs/manual/`
- `docs/generated/sistema/`
- `history/chronicle/` (con subcarpetas por fecha `2026-03-04`, `2026-03-05`, etc.)
- `history/decisions/`
- `history/inspirations/`
- `history/meta/`
- `.agents/scripts/`

#### [Operaciones de Movimiento]
- Mover todos los `docs/2026-03-*.md` a sus respectivas carpetas de fecha en `history/chronicle/`.
- Mover `docs/Directrices_PI_IA.md` y `docs/2026-03-13-09-metafisica-de-trenza.md` a `history/meta/`.
- Mover `examples/cronometro-psp/trenza/` a `spec/reference/cronometro-psp/`. (El resto de la aplicación JS manual se queda en `examples/cronometro-psp/app` como prototipo, no como referencia).
- Dentro de `spec/reference/cronometro-psp/`, renombrar las extensiones de todos los archivos `.helix` a `.trz` si quedara alguno.
- Mover `docs/backup_conversaciones.py` a `.agents/scripts/backup_conversaciones.py`.
- Mover el manual (`docs/2026-03-20-04-manual-usuario-trenza.md`) a `docs/manual/trenza-manual.md`.

### Fase 3: Creación de Artefactos de la v0.0.1
Aquí escribiremos los nuevos archivos raíz y consolidaremos diseño.

#### [NEW] CHANGELOG.md
Formato estandarizado con la primera release note para v0.0.1 detallando el cambio de nombre de Helix a Trenza.

#### [NEW] LICENSE
Texto de la licencia AGPL-3.0 con la cabecera propuesta por Opus (ofreciendo licencia comercial).

#### [NEW] history/decisions/ADR-*.md
Extraeremos/crearemos rápidamente plantillas para los 18 ADRs identificados (añadiendo la Política de 4 Hebras y las Directrices de PI).

#### [MODIFY] README.md y CLAUDE.md
Actualizaremos las rutas para reflejar la nueva topología.

---

## Verification Plan
1. Ejecutaremos `git status` para confirmar que Git ha detectado los `renames` correctamente, no como un borrado seguido de una adición inconexa.
2. Tiraremos del CLI de Trenza contra la nueva ruta `spec/reference/cronometro-psp/trenza` para confirmar que no hemos roto el parser/verificador al cambiar nombres y rutas.
3. Etiquetaremos como `v0.0.1`.
