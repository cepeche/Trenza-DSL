# Revisión del Proyecto y Próximos Pasos (Trenza DSL / Traza)

Tras un análisis profundo de la base de código actual (`ast.py`, `parser.py`, `verifier.py`, `mermaid.py`, `docgen.py` y `cli.py`), hemos logrado estabilizar la **Especificación v0.2.0** resolviendo satisfactoriamente todos los GAPs de diseño, culminando de forma exitosa y elegante con la resolución del GAP-4 (Slots y Fills).

Con Opus redactando el manual, nuestro enfoque debe cambiar de "Investigación y Diseño" a **"Consolidación, Herramientas y Aplicación"**.

## Tiempos de corto plazo (Inmediato)

### 1. Extender `backup_conversaciones.py` (Pendiente)
Aún tenemos pendiente del plan de migración la actualización del script de copias de seguridad.
- **Acción**: Modificar `docs/backup_conversaciones.py` para que comprima y preserve no solo `.gemini/antigravity` sino también las carpetas `.claude` y `.claude-code` del perfil del usuario, para proteger los historiales de ambas IAs.

## Propuestas a Medio Plazo (Evolución de la Herramienta)

### 2. Generación de Código (Code Generation)
El DSL ya es capaz de parsear y verificar la semántica de la interfaz de usuario, exportando el AST a JSON y documentando las pantallas. El paso natural es que Trenza empiece a trabajar para nosotros.
- **Acción**: Crear un nuevo módulo `codegen.py` que consuma el AST y genere esqueletos de componentes UI (p.ej. en React/TypeScript, Svelte, o plantillas HTML puras) junto con las máquinas de estado XState correspondientes para las transiciones y eventos.

### 3. Sistema de Reporte de Errores Amigable
Actualmente, los errores de sintaxis en el archivo `.trz` generan trazas de pila (stack traces) de Python crudas.
- **Acción**: Interceptar excepciones del Parser/Verifier y mostrarlas de forma amigable ("Estilo Rust" o Elm), apuntando a la línea exacta y columna del archivo indicando qué token falló y sugiriendo una corrección.

### 4. Batería de Pruebas Automatizadas (Test Suite)
El proyecto ha crecido en complejidad al añadir herencia (implicit/explicit) e inyecciones (Slots/Fills). Necesitamos una red de seguridad.
- **Acción**: Configurar un framework como `pytest` creando el directorio `tests/` con casos de prueba unitarios para cada módulo y pruebas de regresión usando los archivos de `examples/`.

### 5. Soporte para Editor de Texto (IDE Tooling)
La experiencia de desarrollo al escribir archivos `.trz` se beneficiaría enormemente del resaltado de sintaxis sintético.
- **Acción**: Desarrollar y empaquetar una extensión mínima para VS Code proporcionando gramática TextMate (`.tmLanguage.json`) para colorear palabras clave reservadas (`context`, `role`, `slot`, `fills`, `transitions`, `effects`, `on`, `->`).

---
¿Por qué punto te gustaría que empecemos ahora o después de la comida? Puedo implementar rápidamente el script de Backup (Punto 1) ahora mismo si lo prefieres para dejar todo blindado.
