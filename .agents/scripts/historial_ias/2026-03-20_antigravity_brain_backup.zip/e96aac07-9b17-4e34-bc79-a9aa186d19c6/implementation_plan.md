# Implementación del Prototipo de Parser Trenza en Python

## Goal
Desarrollar un prototipo inicial de parser y verificador para el DSL Trenza en Python. Este prototipo debe ser capaz de procesar un directorio con sistema Trenza (como `examples/cronometro-psp/trenza/`) y emitir un AST intermedio serializado en formato JSON. Se aplicarán de forma estricta las reglas de validación y de conformidad (en particular, las nuevas Reglas de Herencia consensuadas por Claude y Opus).

## Proposed Changes

### 1. Estructura del Prototipo Python

#### [NEW] src/trenza/cli.py
El punto de entrada del programa. Su función es:
- Recibir como parámetro el directorio a analizar (por defecto `examples/cronometro-psp/trenza`).
- Leer `manifest.json` si existe (o inferir `system.trz` si no).
- Orquestar el parseo y validación de todos los archivos `.trz` referenciados.
- Generar y volcar en un archivo el AST con el modelo en JSON resultante.

#### [NEW] src/trenza/ast.py
Este archivo contendrá las clases de datos de Python (idealmente `dataclasses`) que representan las distintas piezas del lenguaje: `Context`, `Role`, `Event`, `Action`, `Transition`, `Effect`, etc. Las estructuras de datos incluirán marcas para distinguir roles heredados de locales.

#### [NEW] src/trenza/parser.py
Analizador léxico y sintáctico que iterará el código fuente de los archivos `.trz` y rellenará las estructuras del AST base. Utilizaremos un esquema orientado a líneas o matching de expresiones regulares para iterar el diseño, priorizando claridad y detección de huecos sobre optimización de velocidad.

#### [NEW] src/trenza/verifier.py
Tras parsear el sistema de directorios completo, este módulo aplica las reglas formales al AST recabado:
- **Herencia Implícita (H1)**: Propagación de los roles del padre a los hijos.
- **Herencia Excepcional / Locales (H2)**: Integración de roles locales, verificación de que las redefiniciones re-declaran el rol entero (como pidió Opus).
- **Prohibición de Eventos Nuevos en Roles Heredados**: Verificación de que los hijos no añaden eventos nuevos (`doble_tap` a alguien que solo tenía `tap`), obligando a crear un rol local si se quiere extender sobre el mismo tipo de objeto.
- **Completitud (H3)**: Cada evento de cada rol listado explícitamente y en ámbito debe tener `handler` por entorno de acción, comprobándose por nivel de jerarquía (y no mezclando contextos "hermanos").

## Verification Plan

### Automated Tests
* Ejecución del CLI apuntando al directorio `examples/cronometro-psp/trenza`.
* El resultado exitoso debería escribir un archivo con un modelo AST (por ejemplo, `examples/cronometro-psp/trenza-ast.json`).
* Este prototipo no generará código en Rust, sólo el AST como prueba formal para certificar la viabilidad de la futura implementación C++/Rust.

### Manual Verification
* Revisión del JSON saliente: Verificar que la resolución de herencia aplicada sobre `ModalHistorial.trz` y otros contextos anidados corresponda a la lógica humana definida en los documentos.
