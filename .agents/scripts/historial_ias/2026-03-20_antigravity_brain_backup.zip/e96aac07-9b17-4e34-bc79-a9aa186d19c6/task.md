# Plan de Implementación: Prototipo Parser Trenza (Python)

**REGLA:** No hacer `git push` hasta que finalice la sesión o el usuario lo pida expresamente.

- [x] Fase 1: Planificación
  - [x] Crear plan de implementación
  - [x] Revisión y aprobación del plan
- [x] Fase 2: Estructura Base y AST
  - [x] Crear estructura de directorios (`src/trenza`)
  - [x] Implementar `ast.py` (Estructuras de datos para serialización JSON)
- [x] Fase 3: Analizador (Parser)
  - [x] Implementar `parser.py` (Lectura y parseo de `.trz`)
  - [x] Parseo de `system.trz` (Contextos base, concurrents, overlays)
  - [x] Parseo de contextos individuales (`.trz`)
- [x] Fase 4: Verificador de Reglas
  - [x] Implementar `verifier.py`
  - [x] Resolver herencias (Reglas H1-H3)
  - [x] Validar prohibición de nuevos eventos en roles heredados
  - [x] Aplicar regla de completitud
- [x] Fase 5: CLI y Salida
  - [x] Implementar `cli.py`
  - [x] Generación de AST compilado en JSON
- [x] Fase 6: Pruebas
  - [x] Ejecutar contra `examples/cronometro-psp/trenza`
- [x] Fase 7: Generador Mermaid
  - [x] Implementar generador de StateDiagram-V2 a partir del AST
  - [x] Integrar en `cli.py` la salida del `.mermaid`

- [ ] Fase 8: Resolución de GAPs de Diseño (Bloque 1)
  - [ ] GAP-1: Eventos de lifecycle (`[al_entrar]`, `[al_salir]`)
  - [ ] GAP-2: Acciones compuestas (múltiples efectos por evento)
  - [ ] GAP-3: Guardas/condiciones en transiciones
  - [ ] GAP-4: Roles condicionales (presentes solo en un contexto concurrente)
  - [ ] GAP-5: Transiciones condicionales (ramificación por estado)
  - [ ] GAP-6: Datos mutables vs inmutables (`data.trz`)
  - [ ] GAP-7: Efectos de entrada con parámetros
  - [ ] GAP-8: Acciones "ignorar" (evento declarado intencionalmente sin efecto)
