# Migración a Trenza-DSL (Estrategia Sin Reescribir Historia)

- [x] Pausar el reemplazo masivo de nombres.
- [ ] Indicar al usuario las instrucciones precisas para clonar el repositorio Trenza-DSL a una nueva carpeta.
- [ ] Indicar los pasos para conectar ambos entornos (si fuera necesario) o simplemente usar la nueva carpeta.
